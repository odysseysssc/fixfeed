// Content script - runs on x.com/twitter.com
// Handles adding accounts to lists via X's internal API

console.log('FixYourFeed content script loaded');

// Shared GraphQL features object (X requires all these - updated Jan 2026)
const GRAPHQL_FEATURES = {
  responsive_web_graphql_exclude_directive_enabled: true,
  verified_phone_label_enabled: false,
  responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
  responsive_web_graphql_timeline_navigation_enabled: true,
  view_counts_everywhere_api_enabled: true,
  tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
  longform_notetweets_inline_media_enabled: true,
  tweetypie_unmention_optimization_enabled: true,
  standardized_nudges_misinfo: true,
  c9s_tweet_anatomy_moderator_badge_enabled: true,
  responsive_web_enhance_cards_enabled: false,
  freedom_of_speech_not_reach_fetch_enabled: true,
  creator_subscriptions_tweet_preview_api_enabled: true,
  responsive_web_twitter_article_tweet_consumption_enabled: true,
  tweet_awards_web_tipping_enabled: false,
  longform_notetweets_rich_text_read_enabled: true,
  responsive_web_edit_tweet_api_enabled: true,
  graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
  longform_notetweets_consumption_enabled: true,
  rweb_video_timestamps_enabled: true,
  responsive_web_media_download_video_enabled: false,
  // Additional required features (Jan 2026)
  articles_preview_enabled: true,
  rweb_tipjar_consumption_enabled: true,
  communities_web_enable_tweet_community_results_fetch: true,
  creator_subscriptions_quote_tweet_preview_enabled: true,
  hidden_profile_subscriptions_enabled: true,
  subscriptions_verification_info_is_identity_verified_enabled: true,
  subscriptions_verification_info_verified_since_enabled: true,
  highlights_tweets_tab_ui_enabled: true,
  responsive_web_twitter_article_notes_tab_enabled: true,
  subscriptions_feature_can_gift_premium: true,
  premium_content_api_read_enabled: false,
  responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
};

// Listen for messages from popup/background
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'ping') {
    sendResponse({ ok: true });
    return true;
  }
  
  if (msg.action === 'addToList') {
    addAccountToList(msg.handle, msg.listId)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true; // Keep channel open for async
  }
  
  if (msg.action === 'unfollow') {
    unfollowAccount(msg.handle)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  
  if (msg.action === 'unfollowById') {
    unfollowByUserId(msg.userId)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  
  if (msg.action === 'resolveUserId') {
    resolveUserIdToHandle(msg.userId)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  
  if (msg.action === 'getListMembers') {
    getListMembers(msg.listId)
      .then(members => sendResponse({ success: true, members: members }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  
  if (msg.action === 'getListMemberHandles') {
    getListMemberHandles(msg.listId)
      .then(handles => sendResponse({ success: true, handles: handles }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  
  if (msg.action === 'getFollowing') {
    getMyUserId()
      .then(userId => getFollowing(userId))
      .then(following => sendResponse({ success: true, following: following }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  
  if (msg.action === 'getMyUserId') {
    getMyUserId()
      .then(userId => sendResponse({ success: true, userId: userId }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

// Listen for messages from web page (for resolve handles feature)
window.addEventListener('message', async (event) => {
  if (event.data && event.data.type === 'FIXFEED_RESOLVE') {
    const result = await resolveUserIdToHandle(event.data.userId);
    window.postMessage({
      type: 'FIXFEED_RESOLVED',
      userId: event.data.userId,
      ...result
    }, '*');
  }
});

// Get CSRF token from cookie
function getCsrfToken() {
  const match = document.cookie.match(/ct0=([^;]+)/);
  return match ? match[1] : null;
}

// Get bearer token - X's public bearer token used by their web app
function getBearerToken() {
  return 'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';
}

// Make authenticated request to X API
async function xApiRequest(url, options = {}) {
  const csrfToken = getCsrfToken();
  if (!csrfToken) {
    throw new Error('Not logged in to X');
  }
  
  const headers = {
    'authorization': `Bearer ${getBearerToken()}`,
    'x-csrf-token': csrfToken,
    'x-twitter-auth-type': 'OAuth2Session',
    'x-twitter-active-user': 'yes',
    'x-twitter-client-language': 'en',
    ...options.headers,
  };
  
  const response = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });
  
  if (!response.ok) {
    const text = await response.text();
    console.error('X API error:', response.status, text);
    throw new Error(`API error: ${response.status}`);
  }
  
  return response.json();
}

// Get user ID from screen name using X's REST API (more reliable)
async function getUserId(screenName) {
  console.log('Looking up user:', screenName);
  
  // Use the simpler REST-style endpoint
  const url = `https://x.com/i/api/1.1/users/show.json?screen_name=${encodeURIComponent(screenName)}`;
  
  try {
    const data = await xApiRequest(url);
    const userId = data?.id_str;
    
    if (!userId) {
      console.error('User lookup response:', data);
      throw new Error('User not found');
    }
    
    console.log('Found user ID:', userId, 'for', screenName);
    return userId;
  } catch (e) {
    console.error('Error looking up user:', screenName, e);
    
    // Fallback: try GraphQL endpoint
    return getUserIdGraphQL(screenName);
  }
}

// Fallback: Get user ID via GraphQL
async function getUserIdGraphQL(screenName) {
  console.log('Trying GraphQL lookup for:', screenName);
  
  const variables = {
    screen_name: screenName,
    withSafetyModeUserFields: true,
  };
  
  const features = {
    hidden_profile_subscriptions_enabled: true,
    rweb_tipjar_consumption_enabled: true,
    responsive_web_graphql_exclude_directive_enabled: true,
    verified_phone_label_enabled: false,
    subscriptions_verification_info_is_identity_verified_enabled: true,
    subscriptions_verification_info_verified_since_enabled: true,
    highlights_tweets_tab_ui_enabled: true,
    responsive_web_twitter_article_notes_tab_enabled: true,
    subscriptions_feature_can_gift_premium: true,
    creator_subscriptions_tweet_preview_api_enabled: true,
    responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
    responsive_web_graphql_timeline_navigation_enabled: true,
  };
  
  const fieldToggles = {
    withAuxiliaryUserLabels: false,
  };
  
  const url = `https://x.com/i/api/graphql/BQ6xjFU6Mgm-WhEP3OiT9w/UserByScreenName?variables=${encodeURIComponent(JSON.stringify(variables))}&features=${encodeURIComponent(JSON.stringify(features))}&fieldToggles=${encodeURIComponent(JSON.stringify(fieldToggles))}`;
  
  const data = await xApiRequest(url);
  const userId = data?.data?.user?.result?.rest_id;
  
  if (!userId) {
    throw new Error('User not found');
  }
  
  console.log('Found user ID via GraphQL:', userId);
  return userId;
}

// Add user to list using REST API
async function addUserToList(userId, listId) {
  console.log('Adding user', userId, 'to list', listId);
  
  // Try REST API first (more reliable)
  const url = 'https://x.com/i/api/1.1/lists/members/create.json';
  
  const formData = new URLSearchParams();
  formData.append('list_id', listId);
  formData.append('user_id', userId);
  
  try {
    const data = await xApiRequest(url, {
      method: 'POST',
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
    });
    
    console.log('Successfully added user to list via REST');
    return true;
  } catch (e) {
    console.log('REST API failed, trying GraphQL...', e);
    return addUserToListGraphQL(userId, listId);
  }
}

// Fallback: Add user to list via GraphQL
async function addUserToListGraphQL(userId, listId) {
  console.log('Trying GraphQL add for user', userId);
  
  const url = 'https://x.com/i/api/graphql/lLNsL7mW6gSEQG6rXP7TNw/ListAddMember';
  
  const body = {
    variables: {
      listId: listId,
      userId: userId,
    },
    features: {
      rweb_lists_timeline_redesign_enabled: true,
      responsive_web_graphql_exclude_directive_enabled: true,
      verified_phone_label_enabled: false,
      responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
      responsive_web_graphql_timeline_navigation_enabled: true,
    },
    queryId: 'lLNsL7mW6gSEQG6rXP7TNw',
  };
  
  const data = await xApiRequest(url, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  
  if (data.errors && data.errors.length > 0) {
    throw new Error(data.errors[0].message || 'Failed to add');
  }
  
  console.log('Successfully added user to list via GraphQL');
  return true;
}

// Main function to add account to list
async function addAccountToList(handle, listId) {
  console.log(`Adding @${handle} to list ${listId}`);
  
  try {
    // Step 1: Get user ID from handle
    const userId = await getUserId(handle);
    
    // Step 2: Add user to list  
    await addUserToList(userId, listId);
    
    return { success: true };
  } catch (e) {
    console.error(`Failed to add @${handle}:`, e);
    return { success: false, error: e.message };
  }
}

// Unfollow account - accepts handle, user_id, or profile URL
async function unfollowAccount(input) {
  console.log(`Unfollowing:`, input);
  
  try {
    var userId;
    
    // Check if input is a user ID URL
    if (input.includes('user_id=')) {
      userId = input.match(/user_id=(\d+)/)?.[1];
      console.log('Extracted user ID from URL:', userId);
    } 
    // Check if input is a direct user ID (just numbers)
    else if (/^\d+$/.test(input)) {
      userId = input;
      console.log('Input is direct user ID:', userId);
    }
    // Otherwise it's a handle - need to look up user ID
    else {
      var handle = input.replace(/^@/, '').replace(/https?:\/\/(x|twitter)\.com\//, '');
      userId = await getUserId(handle);
    }
    
    if (!userId) {
      throw new Error('Could not determine user ID');
    }
    
    // Unfollow using REST API
    const url = 'https://x.com/i/api/1.1/friendships/destroy.json';
    
    const formData = new URLSearchParams();
    formData.append('user_id', userId);
    
    try {
      await xApiRequest(url, {
        method: 'POST',
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
        },
        body: formData.toString(),
      });
      
      console.log('Successfully unfollowed via REST');
      return { success: true };
    } catch (e) {
      console.log('REST API failed, trying GraphQL...', e);
      return unfollowGraphQL(userId);
    }
  } catch (e) {
    console.error(`Failed to unfollow:`, input, e);
    return { success: false, error: e.message };
  }
}

// Fallback: Unfollow via GraphQL
async function unfollowGraphQL(userId) {
  console.log('Trying GraphQL unfollow for user', userId);
  
  const url = 'https://x.com/i/api/graphql/QY4RKCLEzgkwvtUd3x_n2Q/DestroyFriendship';
  
  const body = {
    variables: {
      target_user_id: userId,
    },
    queryId: 'QY4RKCLEzgkwvtUd3x_n2Q',
  };
  
  const data = await xApiRequest(url, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  
  if (data.errors && data.errors.length > 0) {
    throw new Error(data.errors[0].message || 'Failed to unfollow');
  }
  
  console.log('Successfully unfollowed via GraphQL');
  return { success: true };
}

// Resolve user ID to handle by looking up user info
async function resolveUserIdToHandle(userId) {
  console.log('Resolving user ID to handle:', userId);
  
  try {
    // Use the users/show endpoint with user_id
    const url = `https://x.com/i/api/1.1/users/show.json?user_id=${userId}`;
    
    const data = await xApiRequest(url);
    const handle = data?.screen_name;
    
    if (!handle) {
      console.error('No handle in response:', data);
      return { success: false, error: 'No handle found' };
    }
    
    console.log('Resolved', userId, 'to @' + handle);
    return { success: true, handle: handle.toLowerCase() };
  } catch (e) {
    console.error('Error resolving user ID:', userId, e);
    
    // Try GraphQL fallback
    try {
      return await resolveUserIdGraphQL(userId);
    } catch (e2) {
      return { success: false, error: e2.message };
    }
  }
}

// Fallback: Resolve via GraphQL
async function resolveUserIdGraphQL(userId) {
  console.log('Trying GraphQL resolve for:', userId);
  
  const variables = {
    userId: userId,
    withSafetyModeUserFields: true,
  };
  
  const features = {
    hidden_profile_subscriptions_enabled: true,
    responsive_web_graphql_exclude_directive_enabled: true,
    verified_phone_label_enabled: false,
    responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
    responsive_web_graphql_timeline_navigation_enabled: true,
  };
  
  const url = `https://x.com/i/api/graphql/xf3jd90KKBCUxdlI_tNHZw/UserByRestId?variables=${encodeURIComponent(JSON.stringify(variables))}&features=${encodeURIComponent(JSON.stringify(features))}`;
  
  const data = await xApiRequest(url);
  const handle = data?.data?.user?.result?.legacy?.screen_name;
  
  if (!handle) {
    throw new Error('User not found');
  }
  
  console.log('Resolved via GraphQL:', userId, 'to @' + handle);
  return { success: true, handle: handle.toLowerCase() };
}

// Get all members of a list (returns array of user IDs)
async function getListMembers(listId) {
  console.log('Fetching list members for:', listId);
  
  const members = [];
  let cursor = null;
  let pageCount = 0;
  
  while (true) {
    pageCount++;
    const variables = {
      listId: listId,
      count: 100,
    };
    if (cursor) variables.cursor = cursor;
    
    const url = `https://x.com/i/api/graphql/BQp2IEYkgxuSxqbTAr1e1g/ListMembers?variables=${encodeURIComponent(JSON.stringify(variables))}&features=${encodeURIComponent(JSON.stringify(GRAPHQL_FEATURES))}`;
    
    console.log('Fetching list members page', pageCount);
    const data = await xApiRequest(url);
    console.log('List members response:', data);
    
    // Handle different response structures
    let entries = [];
    if (data?.data?.list?.members_timeline?.timeline?.instructions) {
      // Find the instruction with entries
      for (const instruction of data.data.list.members_timeline.timeline.instructions) {
        if (instruction.entries) {
          entries = instruction.entries;
          break;
        } else if (instruction.type === 'TimelineAddEntries' && instruction.entries) {
          entries = instruction.entries;
          break;
        }
      }
    }
    
    console.log('Found', entries.length, 'entries in page', pageCount);
    
    for (const entry of entries) {
      const userId = entry.content?.itemContent?.user_results?.result?.rest_id;
      if (userId) {
        members.push(userId);
      }
    }
    
    // Find cursor for next page
    const cursorEntry = entries.find(e => e.content?.cursorType === 'Bottom' || e.entryId?.startsWith('cursor-bottom'));
    if (cursorEntry?.content?.value) {
      cursor = cursorEntry.content.value;
      console.log('Found next cursor, continuing...');
    } else {
      console.log('No more pages');
      break;
    }
    
    // Rate limit protection
    await new Promise(r => setTimeout(r, 500));
    
    // Safety limit
    if (pageCount > 50) {
      console.log('Hit page limit, stopping');
      break;
    }
  }
  
  console.log('Total list members found:', members.length);
  return members;
}

// Get all member handles from a list (returns array of screen_names)
async function getListMemberHandles(listId) {
  console.log('Fetching list member handles for:', listId);
  
  const handles = [];
  let cursor = null;
  
  while (true) {
    const variables = {
      listId: listId,
      count: 100,
    };
    if (cursor) variables.cursor = cursor;
    
    const url = `https://x.com/i/api/graphql/BQp2IEYkgxuSxqbTAr1e1g/ListMembers?variables=${encodeURIComponent(JSON.stringify(variables))}&features=${encodeURIComponent(JSON.stringify(GRAPHQL_FEATURES))}`;
    
    const data = await xApiRequest(url);
    const entries = data?.data?.list?.members_timeline?.timeline?.instructions?.[0]?.entries || [];
    
    for (const entry of entries) {
      const screenName = entry.content?.itemContent?.user_results?.result?.legacy?.screen_name;
      if (screenName) {
        handles.push(screenName.toLowerCase());
      }
    }
    
    // Find cursor for next page
    const cursorEntry = entries.find(e => e.content?.cursorType === 'Bottom');
    if (cursorEntry?.content?.value) {
      cursor = cursorEntry.content.value;
    } else {
      break;
    }
    
    // Rate limit protection
    await new Promise(r => setTimeout(r, 500));
  }
  
  console.log('Found', handles.length, 'list member handles');
  return handles;
}

// Get accounts the user is following (returns array of user IDs)
async function getFollowing(userId) {
  console.log('Fetching following for user:', userId);
  
  // Try REST API first (more stable)
  try {
    return await getFollowingREST(userId);
  } catch (e) {
    console.log('REST API failed, trying GraphQL:', e.message);
    return await getFollowingGraphQL(userId);
  }
}

// Get following via REST API
async function getFollowingREST(userId) {
  console.log('Fetching following via REST for user:', userId);
  
  const following = [];
  let cursor = -1;
  let pageCount = 0;
  
  while (true) {
    pageCount++;
    let url = `https://x.com/i/api/1.1/friends/ids.json?user_id=${userId}&count=5000`;
    if (cursor !== -1) url += `&cursor=${cursor}`;
    
    console.log('Fetching following page', pageCount);
    const data = await xApiRequest(url);
    console.log('Following REST response:', data);
    
    if (data?.ids) {
      // Convert numeric IDs to strings
      const ids = data.ids.map(id => String(id));
      following.push(...ids);
      console.log('Found', ids.length, 'in page', pageCount, '- total so far:', following.length);
    }
    
    // Check for next cursor
    if (data?.next_cursor && data.next_cursor !== 0) {
      cursor = data.next_cursor;
    } else {
      console.log('No more pages');
      break;
    }
    
    // Rate limit protection
    await new Promise(r => setTimeout(r, 500));
    
    // Safety limit
    if (pageCount > 20) {
      console.log('Hit page limit, stopping');
      break;
    }
  }
  
  console.log('Total following found via REST:', following.length);
  return following;
}

// Get following via GraphQL (fallback)
async function getFollowingGraphQL(userId) {
  console.log('Fetching following via GraphQL for user:', userId);
  
  const following = [];
  let cursor = null;
  let pageCount = 0;
  
  while (true) {
    pageCount++;
    const variables = {
      userId: userId,
      count: 100,
      includePromotedContent: false,
    };
    if (cursor) variables.cursor = cursor;
    
    // Try multiple known query IDs
    const queryIds = [
      'eWTmcJY3EMh-dxIR7CYTKw', // Current as of Jan 2026
      'eWTmcJY3EMh-dxIR7CYTKw', // Alternative
      'PiX8KdP0KYwhQ8FnFsJ8dw', // Old
    ];
    
    let data = null;
    for (const queryId of queryIds) {
      try {
        const url = `https://x.com/i/api/graphql/${queryId}/Following?variables=${encodeURIComponent(JSON.stringify(variables))}&features=${encodeURIComponent(JSON.stringify(GRAPHQL_FEATURES))}`;
        console.log('Trying GraphQL query:', queryId);
        data = await xApiRequest(url);
        break; // Success
      } catch (e) {
        console.log('Query', queryId, 'failed:', e.message);
        continue;
      }
    }
    
    if (!data) {
      throw new Error('All GraphQL queries failed');
    }
    
    console.log('Following GraphQL response:', data);
    
    // Handle different response structures
    let entries = [];
    const instructions = data?.data?.user?.result?.timeline?.timeline?.instructions;
    if (instructions) {
      for (const instruction of instructions) {
        if (instruction.type === 'TimelineAddEntries' && instruction.entries) {
          entries = instruction.entries;
          break;
        } else if (instruction.entries) {
          entries = instruction.entries;
          break;
        }
      }
    }
    
    console.log('Found', entries.length, 'entries in page', pageCount);
    
    for (const entry of entries) {
      const uid = entry.content?.itemContent?.user_results?.result?.rest_id;
      if (uid) {
        following.push(uid);
      }
    }
    
    // Find cursor for next page
    const cursorEntry = entries.find(e => e.content?.cursorType === 'Bottom' || e.entryId?.startsWith('cursor-bottom'));
    if (cursorEntry?.content?.value) {
      cursor = cursorEntry.content.value;
      console.log('Found next cursor, continuing...');
    } else {
      console.log('No more pages');
      break;
    }
    
    // Rate limit protection
    await new Promise(r => setTimeout(r, 500));
    
    // Safety limit
    if (pageCount > 50) {
      console.log('Hit page limit, stopping');
      break;
    }
  }
  
  console.log('Total following found via GraphQL:', following.length);
  return following;
}

// Get current user's ID
async function getMyUserId() {
  console.log('Fetching current user ID...');
  
  // Method 1: Try to get from the page's initial state (fastest)
  try {
    // X embeds user data in the page - look for it in cookies or DOM
    const cookies = document.cookie;
    const twidMatch = cookies.match(/twid=u%3D(\d+)/);
    if (twidMatch) {
      console.log('Found user ID from twid cookie:', twidMatch[1]);
      return twidMatch[1];
    }
  } catch (e) {
    console.log('Could not get ID from cookie:', e);
  }
  
  // Method 2: Use GraphQL Viewer query
  try {
    const variables = {};
    const features = {
      responsive_web_graphql_exclude_directive_enabled: true,
      verified_phone_label_enabled: false,
      responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
      responsive_web_graphql_timeline_navigation_enabled: true,
    };
    
    const url = `https://x.com/i/api/graphql/CwLTHCxolzGvXEAH-DqZlQ/Viewer?variables=${encodeURIComponent(JSON.stringify(variables))}&features=${encodeURIComponent(JSON.stringify(features))}`;
    
    const data = await xApiRequest(url);
    console.log('Viewer response:', data);
    
    const userId = data?.data?.viewer?.user_results?.result?.rest_id;
    if (userId) {
      console.log('Found user ID from Viewer:', userId);
      return userId;
    }
  } catch (e) {
    console.log('Viewer query failed:', e);
  }
  
  // Method 3: Parse from page HTML/scripts
  try {
    const scripts = document.querySelectorAll('script');
    for (const script of scripts) {
      const text = script.textContent || '';
      const match = text.match(/"id_str":"(\d+)"/);
      if (match) {
        console.log('Found user ID from page script:', match[1]);
        return match[1];
      }
    }
  } catch (e) {
    console.log('Could not parse from page:', e);
  }
  
  throw new Error('Could not determine your user ID. Make sure you are logged into X.');
}

// Unfollow by user ID directly
async function unfollowByUserId(userId) {
  console.log('Unfollowing user ID:', userId);
  
  const url = 'https://x.com/i/api/1.1/friendships/destroy.json';
  
  const formData = new URLSearchParams();
  formData.append('user_id', userId);
  
  try {
    const data = await xApiRequest(url, {
      method: 'POST',
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
    });
    
    console.log('Unfollowed user ID:', userId);
    return { success: true, userId: userId };
  } catch (e) {
    // 404 means account doesn't exist or already unfollowed - treat as success
    if (e.message && e.message.includes('404')) {
      console.log('Account not found (already gone/unfollowed):', userId);
      return { success: true, userId: userId, skipped: true, reason: 'not found' };
    }
    throw e;
  }
}
