// State
let state = {
  mode: 'addToList', // 'addToList' or 'clean'
  handles: [],
  listId: null,
  listName: '',
  added: [],
  failed: [],
  skipped: [], // Track skipped (already gone) accounts
  current: null,
  status: 'idle', // idle, running, paused, complete, loading, rateLimited
  totalToProcess: 0, // Total count for clean mode (toUnfollow.length)
};

// Saved progress for resume functionality
let savedProgress = null;
let savedCleanProgress = null;

// Daily limit threshold
const DAILY_LIMIT = 650; // Stop before hitting X's ~700 limit

// Elements
const setupView = document.getElementById('setupView');
const runningView = document.getElementById('runningView');
const completeView = document.getElementById('completeView');

const modeTabs = document.getElementById('modeTabs');
const listUrlSection = document.getElementById('listUrlSection');
const handlesSection = document.getElementById('handlesSection');
const cleanModeInfo = document.getElementById('cleanModeInfo');
const handlesInput = document.getElementById('handlesInput');
const loadedCount = document.getElementById('loadedCount');
const listUrlInput = document.getElementById('listUrlInput');
const listStatus = document.getElementById('listStatus');
const startBtn = document.getElementById('startBtn');

const statusBadge = document.getElementById('statusBadge');
const listNameDisplay = document.getElementById('listNameDisplay');
const addedCount = document.getElementById('addedCount');
const failedCount = document.getElementById('failedCount');
const remainingCount = document.getElementById('remainingCount');
const progressFill = document.getElementById('progressFill');
const currentAvatar = document.getElementById('currentAvatar');
const currentHandle = document.getElementById('currentHandle');
const pauseBtn = document.getElementById('pauseBtn');
const stopBtn = document.getElementById('stopBtn');
const log = document.getElementById('log');

const completeStatus = document.getElementById('completeStatus');
const finalAdded = document.getElementById('finalAdded');
const finalFailed = document.getElementById('finalFailed');
const failedSection = document.getElementById('failedSection');
const failedList = document.getElementById('failedList');
const resetBtn = document.getElementById('resetBtn');

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  // Load state from storage
  const stored = await chrome.storage.local.get(['fixfeed_state', 'fixfeed_saved_progress', 'fixfeed_clean_progress']);
  if (stored.fixfeed_state) {
    state = stored.fixfeed_state;
    updateUI();
  }
  
  // Check for saved progress (unfinished curate batch)
  if (stored.fixfeed_saved_progress) {
    savedProgress = stored.fixfeed_saved_progress;
    showResumeBanner();
  }
  
  // Check for saved clean progress (unfinished clean batch)
  if (stored.fixfeed_clean_progress) {
    savedCleanProgress = stored.fixfeed_clean_progress;
    showCleanResumeBanner();
  }
  
  // Set up mode tabs
  setupModeTabs();
  
  // Set up modal handlers
  setupModalHandlers();
  
  // Set up resume handlers
  setupResumeHandlers();
});

// Mode tab handling
function setupModeTabs() {
  modeTabs.querySelectorAll('.mode-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      state.mode = tab.dataset.mode;
      
      // Update tab styles
      modeTabs.querySelectorAll('.mode-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      // Show/hide sections based on mode
      if (state.mode === 'clean') {
        listUrlSection.style.display = 'block';
        handlesSection.style.display = 'none';
        cleanModeInfo.classList.remove('hidden');
        startBtn.textContent = state.listId ? 'Start Clean Up' : 'Paste list URL first';
        startBtn.classList.add('btn-danger');
      } else {
        // addToList mode
        listUrlSection.style.display = 'block';
        handlesSection.style.display = 'block';
        cleanModeInfo.classList.add('hidden');
        startBtn.textContent = state.handles.length > 0 && state.listId ? `Add ${state.handles.length} to List` : 'Start Adding';
        startBtn.classList.remove('btn-danger');
      }
      
      checkReady();
      saveState();
    });
  });
}

// Parse handles from textarea input
function parseHandles(text) {
  if (!text.trim()) return [];
  
  return text
    .split(/[\n,]+/) // Split by newline or comma
    .map(h => h.trim())
    .map(h => h.replace(/^@/, '')) // Remove @ prefix
    .filter(h => h.length > 0 && /^[a-zA-Z0-9_]+$/.test(h)) // Valid handle chars
    .filter((h, i, arr) => arr.indexOf(h) === i); // Remove duplicates
}

// Handle textarea input
handlesInput.addEventListener('input', () => {
  state.handles = parseHandles(handlesInput.value);
  loadedCount.textContent = state.handles.length;
  checkReady();
  saveState(); // Save as you type
});

// Also handle paste events
handlesInput.addEventListener('paste', () => {
  // Small delay to let paste complete
  setTimeout(() => {
    state.handles = parseHandles(handlesInput.value);
    loadedCount.textContent = state.handles.length;
    checkReady();
    saveState(); // Save after paste
  }, 10);
});

// Parse list URL to extract ID
function parseListUrl(url) {
  if (!url) return null;
  
  // Match patterns like:
  // https://x.com/i/lists/123456789
  // https://twitter.com/i/lists/123456789
  // x.com/i/lists/123456789
  // Just the ID: 123456789
  
  const match = url.match(/lists\/(\d+)/);
  if (match) {
    return match[1];
  }
  
  // Check if it's just a number
  if (/^\d+$/.test(url.trim())) {
    return url.trim();
  }
  
  return null;
}

// Handle list URL input
listUrlInput.addEventListener('input', () => {
  const url = listUrlInput.value.trim();
  const listId = parseListUrl(url);
  
  if (listId) {
    state.listId = listId;
    state.listName = 'List ' + listId;
    listStatus.textContent = '✓ List ID: ' + listId;
    listStatus.className = 'list-status valid';
  } else if (url) {
    state.listId = null;
    state.listName = '';
    listStatus.textContent = 'Invalid list URL';
    listStatus.className = 'list-status invalid';
  } else {
    state.listId = null;
    state.listName = '';
    listStatus.textContent = '';
    listStatus.className = 'list-status';
  }
  
  checkReady();
  saveState(); // Save as you type
});

// Check if ready to start
function checkReady() {
  let ready = false;
  
  if (state.mode === 'clean') {
    ready = state.listId != null;
    if (ready) {
      startBtn.textContent = 'Start Clean Up';
    } else {
      startBtn.textContent = 'Paste list URL first';
    }
  } else {
    // addToList mode
    ready = state.handles.length > 0 && state.listId;
    if (ready) {
      startBtn.textContent = `Add ${state.handles.length} to List`;
    } else {
      startBtn.textContent = 'Start Adding';
    }
  }
  
  startBtn.disabled = !ready;
}

// Start button
startBtn.addEventListener('click', async () => {
  if (state.mode === 'addToList' && (state.handles.length === 0 || !state.listId)) return;
  if (state.mode === 'clean' && !state.listId) return;
  
  // For addToList mode with large batches, show warning
  if (state.mode === 'addToList' && state.handles.length > 100) {
    showWarningModal(state.handles.length);
    return;
  }
  
  // Otherwise start directly
  startProcess();
});

// Actually start the process (called after warning confirmation or for small batches)
function startProcess() {
  state.status = 'running';
  state.added = [];
  state.failed = [];
  state.current = null;
  
  saveState();
  showView('running');
  
  // Hide rate limit notice if showing
  document.getElementById('rateLimitNotice').classList.add('hidden');
  
  if (state.mode === 'clean') {
    listNameDisplay.textContent = 'Cleaning...';
    statusBadge.textContent = 'Loading...';
    statusBadge.className = 'status running';
    updateRunningUI();
    addLog('Starting clean up...', 'info');
    
    // Send clean action to background
    chrome.runtime.sendMessage({
      action: 'startClean',
      listId: state.listId
    });
  } else {
    listNameDisplay.textContent = state.listName;
    statusBadge.textContent = 'Running...';
    updateRunningUI();
    
    // Start the process via background script
    chrome.runtime.sendMessage({
      action: 'start',
      mode: state.mode,
      handles: state.handles,
      listId: state.listId,
      listName: state.listName,
      dailyLimit: DAILY_LIMIT
    });
  }
}

// Warning modal handlers
function setupModalHandlers() {
  document.getElementById('modalCancel').addEventListener('click', () => {
    document.getElementById('warningModal').classList.remove('active');
  });
  
  document.getElementById('modalConfirm').addEventListener('click', () => {
    document.getElementById('warningModal').classList.remove('active');
    startProcess();
  });
}

// Show warning modal for large batches
function showWarningModal(count) {
  document.getElementById('modalCount').textContent = count;
  
  if (count > DAILY_LIMIT) {
    const days = Math.ceil(count / DAILY_LIMIT);
    document.getElementById('modalDays').textContent = days;
    document.getElementById('modalMultiDay').style.display = 'inline';
  } else {
    document.getElementById('modalMultiDay').style.display = 'none';
  }
  
  document.getElementById('warningModal').classList.add('active');
}

// Resume banner handlers
function setupResumeHandlers() {
  document.getElementById('resumeBtn').addEventListener('click', () => {
    if (savedProgress) {
      // Restore state from saved progress
      state.handles = savedProgress.remainingHandles;
      state.listId = savedProgress.listId;
      state.listName = savedProgress.listName;
      state.mode = 'addToList';
      
      // Update UI
      handlesInput.value = state.handles.map(h => '@' + h).join('\n');
      loadedCount.textContent = state.handles.length;
      listUrlInput.value = 'https://x.com/i/lists/' + state.listId;
      listStatus.textContent = '✓ List ID: ' + state.listId;
      listStatus.className = 'list-status valid';
      
      // Hide banner and start
      document.getElementById('resumeBanner').classList.add('hidden');
      
      // Clear saved progress
      chrome.storage.local.remove(['fixfeed_saved_progress']);
      savedProgress = null;
      
      // Start process
      startProcess();
    }
  });
  
  document.getElementById('clearResumeBtn').addEventListener('click', () => {
    chrome.storage.local.remove(['fixfeed_saved_progress']);
    savedProgress = null;
    document.getElementById('resumeBanner').classList.add('hidden');
  });
}

// Show resume banner
function showResumeBanner() {
  if (savedProgress && savedProgress.remainingHandles && savedProgress.remainingHandles.length > 0) {
    document.getElementById('resumeRemaining').textContent = savedProgress.remainingHandles.length;
    document.getElementById('resumeBanner').classList.remove('hidden');
  }
}

// Show clean resume banner (reuses the same banner with different text)
function showCleanResumeBanner() {
  if (savedCleanProgress && savedCleanProgress.toUnfollow && savedCleanProgress.toUnfollow.length > 0) {
    // Switch to clean mode tab
    state.mode = 'clean';
    modeTabs.querySelectorAll('.mode-tab').forEach(t => t.classList.remove('active'));
    modeTabs.querySelector('[data-mode="clean"]').classList.add('active');
    
    document.getElementById('resumeRemaining').textContent = savedCleanProgress.toUnfollow.length;
    document.getElementById('resumeBanner').querySelector('h4').textContent = '🧹 Unfinished clean up';
    document.getElementById('resumeBanner').querySelector('p').innerHTML = 
      `<span id="resumeRemaining">${savedCleanProgress.toUnfollow.length}</span> accounts remaining to unfollow`;
    document.getElementById('resumeBanner').classList.remove('hidden');
    
    // Update resume button handler for clean mode
    document.getElementById('resumeBtn').onclick = resumeCleanProcess;
    document.getElementById('clearResumeBtn').onclick = clearCleanProgress;
  }
}

// Resume clean process
function resumeCleanProcess() {
  if (savedCleanProgress) {
    state.mode = 'clean';
    state.listId = savedCleanProgress.listId;
    state.status = 'running';
    state.added = savedCleanProgress.added || [];
    state.failed = savedCleanProgress.failed || [];
    state.skipped = savedCleanProgress.skipped || [];
    state.totalToProcess = savedCleanProgress.toUnfollow.length;
    
    // Hide banner
    document.getElementById('resumeBanner').classList.add('hidden');
    
    saveState();
    showView('running');
    
    listNameDisplay.textContent = 'Resuming clean...';
    statusBadge.textContent = 'Running...';
    statusBadge.className = 'status running';
    updateRunningUI();
    addLog(`Resuming clean up: ${savedCleanProgress.toUnfollow.length} remaining...`, 'info');
    
    // Send resume clean action to background
    chrome.runtime.sendMessage({
      action: 'resumeClean',
      toUnfollow: savedCleanProgress.toUnfollow,
      listId: savedCleanProgress.listId,
      added: savedCleanProgress.added || [],
      failed: savedCleanProgress.failed || [],
      skipped: savedCleanProgress.skipped || []
    });
    
    // Clear saved progress
    chrome.storage.local.remove(['fixfeed_clean_progress']);
    savedCleanProgress = null;
  }
}

// Clear clean progress
function clearCleanProgress() {
  chrome.storage.local.remove(['fixfeed_clean_progress']);
  savedCleanProgress = null;
  document.getElementById('resumeBanner').classList.add('hidden');
}

// Pause/Resume
pauseBtn.addEventListener('click', () => {
  if (state.status === 'running') {
    state.status = 'paused';
    pauseBtn.textContent = '▶ Resume';
    statusBadge.textContent = 'Paused';
    statusBadge.className = 'status paused';
    chrome.runtime.sendMessage({ action: 'pause' });
  } else if (state.status === 'paused') {
    state.status = 'running';
    pauseBtn.textContent = '⏸ Pause';
    statusBadge.textContent = 'Running...';
    statusBadge.className = 'status running';
    chrome.runtime.sendMessage({ action: 'resume' });
  }
  saveState();
});

// Stop
stopBtn.addEventListener('click', () => {
  state.status = 'complete';
  chrome.runtime.sendMessage({ action: 'stop' });
  showComplete();
});

// Reset
resetBtn.addEventListener('click', () => {
  state = {
    mode: 'addToList',
    handles: [],
    listId: null,
    listName: '',
    added: [],
    failed: [],
    current: null,
    status: 'idle',
    totalToProcess: 0,
  };
  chrome.storage.local.remove(['fixfeed_state']);
  handlesInput.value = '';
  listUrlInput.value = '';
  listStatus.textContent = '';
  listStatus.className = 'list-status';
  loadedCount.textContent = '0';
  startBtn.disabled = true;
  startBtn.textContent = 'Start Adding';
  startBtn.classList.remove('btn-danger');
  listUrlSection.style.display = 'block';
  handlesSection.style.display = 'block';
  cleanModeInfo.classList.add('hidden');
  modeTabs.querySelectorAll('.mode-tab').forEach(t => t.classList.remove('active'));
  modeTabs.querySelector('[data-mode="addToList"]').classList.add('active');
  showView('setup');
  log.innerHTML = '';
});

// Listen for updates from background script
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'progress') {
    state.current = msg.handle;
    state.added = msg.added || state.added;
    state.failed = msg.failed || state.failed;
    state.skipped = msg.skipped || state.skipped || [];
    // Capture total for clean mode
    if (msg.total !== undefined) {
      state.totalToProcess = msg.total;
    }
    saveState();
    updateRunningUI();
    addLog(msg.message, msg.success ? 'success' : 'info');
  } else if (msg.type === 'complete') {
    state.status = 'complete';
    state.added = msg.added;
    state.failed = msg.failed;
    state.skipped = msg.skipped || [];
    // Clear any saved progress on complete
    chrome.storage.local.remove(['fixfeed_saved_progress']);
    saveState();
    showComplete();
  } else if (msg.type === 'rateLimited') {
    // Daily limit reached - save progress for tomorrow
    state.status = 'rateLimited';
    state.added = msg.added;
    state.failed = msg.failed;
    state.skipped = msg.skipped || [];
    state.failed = msg.failed;
    
    // Save remaining handles for resume
    const progress = {
      remainingHandles: msg.remainingHandles,
      listId: state.listId,
      listName: state.listName,
      savedAt: new Date().toISOString()
    };
    chrome.storage.local.set({ fixfeed_saved_progress: progress });
    
    saveState();
    showRateLimitPause(msg.added.length, msg.remainingHandles.length);
  } else if (msg.type === 'error') {
    addLog(msg.message, 'error');
    if (msg.handle) {
      state.failed.push(msg.handle);
    }
    updateRunningUI();
  }
});

// Show rate limit pause UI
function showRateLimitPause(addedCount, remainingCount) {
  document.getElementById('rateLimitNotice').classList.remove('hidden');
  document.getElementById('rateLimitAdded').textContent = addedCount;
  document.getElementById('rateLimitRemaining').textContent = remainingCount;
  
  // Update text based on mode
  if (state.mode === 'clean') {
    document.getElementById('rateLimitAction').textContent = 'Unfollowed';
    document.getElementById('rateLimitActionVerb').textContent = 'unfollow';
    document.getElementById('rateLimitTiming').textContent = 'Resume in ~1 hour';
  } else {
    document.getElementById('rateLimitAction').textContent = 'Added';
    document.getElementById('rateLimitActionVerb').textContent = 'add';
    document.getElementById('rateLimitTiming').textContent = 'Resume tomorrow';
  }
  
  statusBadge.textContent = 'Paused';
  statusBadge.className = 'status paused';
  
  // Update button to show close instead of pause/stop
  document.querySelector('.btn-row').innerHTML = `
    <button class="btn btn-primary" id="closePausedBtn">Close (resume later)</button>
  `;
  document.getElementById('closePausedBtn').addEventListener('click', () => {
    // Just close popup, progress is saved
    window.close();
  });
}

// UI Helpers
function showView(view) {
  setupView.classList.toggle('hidden', view !== 'setup');
  runningView.classList.toggle('hidden', view !== 'running');
  completeView.classList.toggle('hidden', view !== 'complete');
}

function updateUI() {
  // Restore the correct mode tab
  modeTabs.querySelectorAll('.mode-tab').forEach(t => t.classList.remove('active'));
  const activeTab = modeTabs.querySelector(`[data-mode="${state.mode}"]`);
  if (activeTab) activeTab.classList.add('active');
  
  // Show/hide sections based on mode
  if (state.mode === 'clean') {
    listUrlSection.style.display = 'block';
    handlesSection.style.display = 'none';
    cleanModeInfo.classList.remove('hidden');
    startBtn.classList.add('btn-danger');
  } else {
    listUrlSection.style.display = 'block';
    handlesSection.style.display = 'block';
    cleanModeInfo.classList.add('hidden');
    startBtn.classList.remove('btn-danger');
  }
  
  if (state.handles.length > 0) {
    handlesInput.value = state.handles.map(h => '@' + h).join('\n');
    loadedCount.textContent = state.handles.length;
  }
  
  if (state.listId) {
    listUrlInput.value = 'https://x.com/i/lists/' + state.listId;
    listStatus.textContent = '✓ List ID: ' + state.listId;
    listStatus.className = 'list-status valid';
  }
  
  if (state.status === 'running' || state.status === 'paused') {
    showView('running');
    listNameDisplay.textContent = state.mode === 'clean' ? 'Cleaning...' : state.listName;
    updateRunningUI();
    if (state.status === 'paused') {
      pauseBtn.textContent = '▶ Resume';
      statusBadge.textContent = 'Paused';
      statusBadge.className = 'status paused';
    }
  } else if (state.status === 'complete') {
    showComplete();
  } else {
    showView('setup');
    checkReady();
  }
}

function updateRunningUI() {
  // Use totalToProcess for clean mode, handles.length for addToList mode
  const total = state.mode === 'clean' ? state.totalToProcess : state.handles.length;
  const skippedCount = state.skipped ? state.skipped.length : 0;
  const actualAdded = state.added.length - skippedCount; // Real unfollows (not skipped)
  const done = state.added.length + state.failed.length;
  const remaining = Math.max(0, total - done);
  const percent = total > 0 ? (done / total) * 100 : 0;
  
  // In clean mode, show actual unfollows vs skipped separately
  if (state.mode === 'clean') {
    document.getElementById('addedCount').textContent = actualAdded;
    document.getElementById('skippedStat').style.display = 'block';
    document.getElementById('skippedCount').textContent = skippedCount;
    document.getElementById('addedLabel').textContent = 'unfollowed';
  } else {
    document.getElementById('addedCount').textContent = state.added.length;
    document.getElementById('skippedStat').style.display = 'none';
    document.getElementById('addedLabel').textContent = 'added';
  }
  
  failedCount.textContent = state.failed.length;
  remainingCount.textContent = remaining;
  progressFill.style.width = percent + '%';
  
  if (state.current) {
    currentHandle.textContent = '@' + state.current;
    // Don't show avatar for ID-based unfollows
    if (state.mode === 'clean' && state.current.startsWith('ID:')) {
      currentAvatar.style.display = 'none';
    } else {
      currentAvatar.src = 'https://unavatar.io/x/' + state.current;
      currentAvatar.style.display = 'block';
    }
  } else {
    currentHandle.textContent = '—';
    currentAvatar.style.display = 'none';
  }
}

function showComplete() {
  showView('complete');
  finalAdded.textContent = state.added.length;
  finalFailed.textContent = state.failed.length;
  
  // Update label based on mode
  const addedLabel = completeView.querySelector('.stat:first-child .stat-label');
  if (addedLabel) {
    addedLabel.textContent = state.mode === 'clean' ? 'UNFOLLOWED' : 'ADDED';
  }
  
  if (state.failed.length > 0) {
    failedSection.classList.remove('hidden');
    if (state.mode === 'clean') {
      // For clean mode, show user IDs
      failedList.innerHTML = state.failed.map(id => 
        '<a href="https://twitter.com/intent/user?user_id=' + id + '" target="_blank">ID:' + id.slice(-8) + '</a>'
      ).join('<br>');
    } else {
      failedList.innerHTML = state.failed.map(h => 
        '<a href="https://x.com/' + h + '" target="_blank">@' + h + '</a>'
      ).join('<br>');
    }
  } else {
    failedSection.classList.add('hidden');
  }
  
  if (state.failed.length === 0) {
    if (state.mode === 'clean') {
      completeStatus.textContent = '🧹 Feed cleaned!';
    } else {
      completeStatus.textContent = '✓ All accounts added!';
    }
    completeStatus.style.color = '#4ade80';
  } else if (state.added.length === 0) {
    completeStatus.textContent = state.mode === 'clean' ? 'Failed to unfollow accounts' : 'Failed to add accounts';
    completeStatus.style.color = '#f87171';
  } else {
    const action = state.mode === 'clean' ? 'Unfollowed' : 'Added';
    completeStatus.textContent = `${action} ${state.added.length}, ${state.failed.length} failed`;
    completeStatus.style.color = '#fbbf24';
  }
}

function addLog(message, type = 'info') {
  const entry = document.createElement('div');
  entry.className = 'log-entry ' + type;
  entry.textContent = message;
  log.insertBefore(entry, log.firstChild);
  
  // Keep only last 50 entries
  while (log.children.length > 50) {
    log.removeChild(log.lastChild);
  }
}

function saveState() {
  chrome.storage.local.set({ fixfeed_state: state });
}
