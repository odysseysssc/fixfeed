// Background service worker
// Coordinates the add-to-list, unfollow, and resolve handles processes

console.log('FixYourFeed background service worker started');

let state = {
  running: false,
  paused: false,
  mode: 'addToList',
  handles: [],
  listId: null,
  listName: '',
  added: [],
  failed: [],
  currentIndex: 0,
};

// Listen for messages from popup and content scripts
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log('Background received message:', msg.action, msg);
  
  if (msg.action === 'start') {
    startProcess(msg.mode, msg.handles, msg.listId, msg.listName, msg.dailyLimit);
  } else if (msg.action === 'startClean') {
    startCleanProcess(msg.listId);
  } else if (msg.action === 'resumeClean') {
    resumeCleanProcess(msg.toUnfollow, msg.listId, msg.added, msg.failed, msg.skipped);
  } else if (msg.action === 'pause') {
    state.paused = true;
  } else if (msg.action === 'resume') {
    state.paused = false;
    if (state.mode === 'clean') {
      processNextClean();
    } else {
      processNext();
    }
  } else if (msg.action === 'stop') {
    state.running = false;
    state.paused = false;
  } else if (msg.action === 'resolveUserId') {
    // Handle resolve request - forward to X tab
    console.log('Resolving user ID:', msg.userId);
    resolveUserIdViaTab(msg.userId)
      .then(result => {
        console.log('Resolve result:', result);
        sendResponse(result);
      })
      .catch(err => {
        console.error('Resolve error:', err);
        sendResponse({ success: false, error: err.message });
      });
    return true; // Keep channel open for async
  }
});

// Listen for external messages (from fixyourfeed.xyz)
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'resolveUserId') {
    resolveUserIdViaTab(msg.userId).then(sendResponse);
    return true;
  }
});

// Resolve user ID by sending request to X tab
async function resolveUserIdViaTab(userId) {
  try {
    let tabs = await chrome.tabs.query({ url: ['https://x.com/*', 'https://twitter.com/*'] });
    console.log('Found X tabs:', tabs.length);
    
    if (tabs.length === 0) {
      console.log('No X tab found');
      return { success: false, error: 'No X tab open. Please open x.com' };
    }
    
    // Try each tab until one works
    for (let tab of tabs) {
      console.log('Trying tab:', tab.id, tab.url);
      try {
        const response = await chrome.tabs.sendMessage(tab.id, {
          action: 'resolveUserId',
          userId: userId
        });
        console.log('Response from tab', tab.id, ':', response);
        if (response) return response;
      } catch (e) {
        console.log('Tab', tab.id, 'failed:', e.message);
        continue;
      }
    }
    
    return { success: false, error: 'Could not connect to X tab. Refresh x.com and try again.' };
  } catch (e) {
    console.error('Error resolving user ID:', e);
    return { success: false, error: e.message };
  }
}

// Ensure content script is injected
async function ensureContentScript(tabId) {
  try {
    // Try to ping the content script
    await chrome.tabs.sendMessage(tabId, { action: 'ping' });
    return true;
  } catch (e) {
    // Content script not loaded, inject it
    console.log('Injecting content script into tab', tabId);
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      });
      // Wait a bit for it to initialize
      await new Promise(resolve => setTimeout(resolve, 500));
      return true;
    } catch (err) {
      console.error('Failed to inject content script:', err);
      return false;
    }
  }
}

// Find an existing X tab
async function findXTab() {
  const tabs = await chrome.tabs.query({ url: ['https://x.com/*', 'https://twitter.com/*'] });
  return tabs[0] || null;
}

// Start the process
async function startProcess(mode, handles, listId, listName, dailyLimit) {
  state = {
    running: true,
    paused: false,
    mode: mode || 'addToList',
    handles: handles,
    listId: listId,
    listName: listName,
    added: [],
    failed: [],
    skipped: [],
    currentIndex: 0,
    existingMembers: new Set(),
    dailyLimit: dailyLimit || 650,
    dailyAdded: 0, // Track adds in this session
  };
  
  // Save state
  await chrome.storage.local.set({ fixfeed_process: state });
  
  // Find or create a tab on x.com
  let tab = await findXTab();
  console.log('Found X tab:', tab?.id, tab?.url);
  
  if (!tab) {
    notifyPopup({
      type: 'error',
      message: 'No X tab open. Please open x.com and try again.',
    });
    return;
  }
  
  state.tabId = tab.id;
  
  // For addToList mode, pre-fetch existing members to avoid duplicates
  if (mode === 'addToList' && listId) {
    notifyPopup({
      type: 'progress',
      message: 'Checking existing list members...',
      added: [],
      failed: [],
    });
    
    try {
      const result = await chrome.tabs.sendMessage(tab.id, {
        action: 'getListMembers',
        listId: listId
      });
      
      if (result.success && result.members) {
        // We have user IDs, but we need handles to compare
        // Store the IDs for now, we'll resolve as we go
        console.log('List already has', result.members.length, 'members');
        state.existingMemberIds = new Set(result.members);
        
        // Also fetch handles for existing members (so we can skip by handle)
        const existingHandlesResult = await chrome.tabs.sendMessage(tab.id, {
          action: 'getListMemberHandles',
          listId: listId
        });
        
        if (existingHandlesResult.success && existingHandlesResult.handles) {
          state.existingMembers = new Set(existingHandlesResult.handles.map(h => h.toLowerCase()));
          console.log('Existing handles:', state.existingMembers.size);
          
          // Filter out handles already on the list
          const originalCount = state.handles.length;
          state.handles = state.handles.filter(h => !state.existingMembers.has(h.toLowerCase()));
          const skippedCount = originalCount - state.handles.length;
          
          if (skippedCount > 0) {
            notifyPopup({
              type: 'progress',
              message: `Skipped ${skippedCount} already on list. ${state.handles.length} to add.`,
              added: [],
              failed: [],
            });
          }
        }
      }
    } catch (e) {
      console.log('Could not pre-fetch list members:', e);
      // Continue anyway, worst case we get "already added" errors
    }
  }
  
  if (state.handles.length === 0) {
    notifyPopup({
      type: 'complete',
      added: [],
      failed: [],
      message: 'All handles already on list!'
    });
    return;
  }
  
  // Start processing
  processNext();
}

// Process next account
async function processNext() {
  if (!state.running || state.paused) return;
  
  // Check if we've hit the daily limit
  if (state.dailyLimit && state.dailyAdded >= state.dailyLimit) {
    console.log('Daily limit reached:', state.dailyAdded);
    state.running = false;
    
    // Calculate remaining handles
    const remainingHandles = state.handles.slice(state.currentIndex);
    
    notifyPopup({
      type: 'rateLimited',
      added: state.added,
      failed: state.failed,
      remainingHandles: remainingHandles,
      message: `Daily limit reached. ${remainingHandles.length} accounts remaining.`
    });
    return;
  }
  
  if (state.currentIndex >= state.handles.length) {
    // Complete
    state.running = false;
    notifyPopup({
      type: 'complete',
      added: state.added,
      failed: state.failed,
    });
    return;
  }
  
  const handle = state.handles[state.currentIndex];
  
  notifyPopup({
    type: 'progress',
    handle: handle,
    added: state.added,
    failed: state.failed,
    message: `Adding @${handle}... (${state.dailyAdded || 0}/${state.dailyLimit || '∞'} today)`,
    success: false,
  });
  
  try {
    console.log('Sending addToList for', handle, 'to tab', state.tabId);
    
    const response = await chrome.tabs.sendMessage(state.tabId, {
      action: 'addToList',
      handle: handle,
      listId: state.listId,
    });
    
    console.log('Response:', response);
    
    if (response && response.success) {
      state.added.push(handle);
      state.dailyAdded = (state.dailyAdded || 0) + 1;
      notifyPopup({
        type: 'progress',
        handle: handle,
        added: state.added,
        failed: state.failed,
        message: `✓ Added @${handle} (${state.dailyAdded}/${state.dailyLimit || '∞'} today)`,
        success: true,
      });
      state.currentIndex++;
      await chrome.storage.local.set({ fixfeed_process: state });
      const delay = 5000 + Math.random() * 3000;
      setTimeout(processNext, delay);
    } else {
      throw new Error(response?.error || 'Unknown error');
    }
  } catch (e) {
    console.error(`Failed to add @${handle}:`, e);
    
    // Check for rate limit (429) or forbidden (403 - often means rate limited too)
    if (e.message && (e.message.includes('429') || e.message.includes('403'))) {
      console.log('Rate limit detected, pausing for daily limit');
      state.running = false;
      
      // Calculate remaining handles
      const remainingHandles = state.handles.slice(state.currentIndex);
      
      notifyPopup({
        type: 'rateLimited',
        added: state.added,
        failed: state.failed,
        remainingHandles: remainingHandles,
        message: `Rate limited by X. ${remainingHandles.length} accounts remaining.`
      });
      return;
    }
    
    state.failed.push(handle);
    notifyPopup({
      type: 'error',
      handle: handle,
      message: `✗ Failed @${handle}: ${e.message}`,
    });
    state.currentIndex++;
    await chrome.storage.local.set({ fixfeed_process: state });
    const delay = 5000 + Math.random() * 3000;
    setTimeout(processNext, delay);
  }
}

// Resume clean process from saved progress
async function resumeCleanProcess(toUnfollow, listId, added, failed, skipped) {
  // Find X tab
  const tab = await findXTab();
  if (!tab) {
    notifyPopup({
      type: 'error',
      message: 'No X tab open. Please open x.com and try again.',
    });
    return;
  }
  
  state = {
    running: true,
    paused: false,
    mode: 'clean',
    listId: listId,
    toUnfollow: toUnfollow,
    added: added || [],
    failed: failed || [],
    skipped: skipped || [],
    currentIndex: 0,
    tabId: tab.id,
    dailyUnfollowed: 0, // Reset daily counter for new session
  };
  
  console.log('Resuming clean process with', toUnfollow.length, 'remaining');
  
  notifyPopup({
    type: 'progress',
    message: `Resuming: ${toUnfollow.length} accounts to unfollow`,
    added: state.added,
    failed: state.failed,
    skipped: state.skipped,
    total: toUnfollow.length,
  });
  
  // Save state and start
  await chrome.storage.local.set({ fixfeed_process: state });
  
  // Small delay then start
  setTimeout(processNextClean, 1000);
}

// Clean mode - unfollow everyone not on a list
async function startCleanProcess(listId) {
  state = {
    running: true,
    paused: false,
    mode: 'clean',
    listId: listId,
    safeList: [], // User IDs on the safe list
    following: [], // User IDs we're following
    toUnfollow: [], // User IDs to unfollow
    added: [],
    failed: [],
    skipped: [], // Track skipped (already gone) accounts
    currentIndex: 0,
    dailyUnfollowed: 0, // Track unfollows in this session
  };
  
  // Find X tab
  const tab = await findXTab();
  if (!tab) {
    notifyPopup({
      type: 'error',
      message: 'No X tab open. Please open x.com and try again.',
    });
    return;
  }
  state.tabId = tab.id;
  
  notifyPopup({
    type: 'progress',
    message: 'Fetching safe list members...',
    added: [],
    failed: [],
    skipped: [],
  });
  
  try {
    // Step 1: Get all members of the safe list
    console.log('Fetching list members for:', listId);
    const listResult = await chrome.tabs.sendMessage(tab.id, {
      action: 'getListMembers',
      listId: listId
    });
    
    if (!listResult.success) {
      throw new Error(listResult.error || 'Failed to fetch list members');
    }
    
    state.safeList = listResult.members;
    console.log('Safe list has', state.safeList.length, 'members');
    
    notifyPopup({
      type: 'progress',
      message: `Found ${state.safeList.length} accounts on safe list. Fetching your following...`,
      added: [],
      failed: [],
    });
    
    // Step 2: Get everyone we're following
    console.log('Fetching following...');
    const followingResult = await chrome.tabs.sendMessage(tab.id, {
      action: 'getFollowing'
    });
    
    if (!followingResult.success) {
      throw new Error(followingResult.error || 'Failed to fetch following');
    }
    
    state.following = followingResult.following;
    console.log('Following', state.following.length, 'accounts');
    
    // Step 3: Find accounts to unfollow (following but not on safe list)
    const safeSet = new Set(state.safeList);
    state.toUnfollow = state.following.filter(id => !safeSet.has(id));
    
    console.log('Will unfollow', state.toUnfollow.length, 'accounts');
    
    notifyPopup({
      type: 'progress',
      message: `Found ${state.toUnfollow.length} accounts to unfollow (${state.following.length} following, ${state.safeList.length} safe)`,
      added: [],
      failed: [],
      total: state.toUnfollow.length,
    });
    
    if (state.toUnfollow.length === 0) {
      notifyPopup({
        type: 'complete',
        added: [],
        failed: [],
      });
      return;
    }
    
    // Save state and start processing
    await chrome.storage.local.set({ fixfeed_process: state });
    
    // Small delay then start
    setTimeout(processNextClean, 1000);
    
  } catch (e) {
    console.error('Error in clean process:', e);
    notifyPopup({
      type: 'error',
      message: 'Error: ' + e.message,
    });
  }
}

// Process next unfollow in clean mode
async function processNextClean() {
  if (!state.running || state.paused) return;
  
  // Check if we've hit the daily limit (use 150 for unfollows - more conservative)
  const UNFOLLOW_DAILY_LIMIT = 150;
  if (state.dailyUnfollowed && state.dailyUnfollowed >= UNFOLLOW_DAILY_LIMIT) {
    console.log('Daily unfollow limit reached:', state.dailyUnfollowed);
    state.running = false;
    
    // Calculate remaining
    const remainingIds = state.toUnfollow.slice(state.currentIndex);
    
    // Save progress for resume
    const progress = {
      mode: 'clean',
      listId: state.listId,
      toUnfollow: remainingIds,
      added: state.added,
      failed: state.failed,
      savedAt: new Date().toISOString()
    };
    await chrome.storage.local.set({ fixfeed_clean_progress: progress });
    
    notifyPopup({
      type: 'rateLimited',
      added: state.added,
      failed: state.failed,
      remainingHandles: remainingIds, // reusing this field
      message: `Daily limit reached. ${remainingIds.length} accounts remaining.`
    });
    return;
  }
  
  if (state.currentIndex >= state.toUnfollow.length) {
    // Complete
    state.running = false;
    // Clear any saved progress
    await chrome.storage.local.remove(['fixfeed_clean_progress']);
    notifyPopup({
      type: 'complete',
      added: state.added,
      failed: state.failed,
    });
    return;
  }
  
  const userId = state.toUnfollow[state.currentIndex];
  
  notifyPopup({
    type: 'progress',
    handle: 'ID:' + userId.slice(-6),
    added: state.added,
    failed: state.failed,
    message: `Unfollowing ${state.currentIndex + 1}/${state.toUnfollow.length}... (${state.dailyUnfollowed || 0} today)`,
    success: false,
    total: state.toUnfollow.length,
  });
  
  try {
    console.log('Unfollowing user ID:', userId);
    const response = await chrome.tabs.sendMessage(state.tabId, {
      action: 'unfollowById',
      userId: userId
    });
    
    console.log('Unfollow response:', response);
    
    if (response && response.success) {
      state.added.push(userId);
      // Track skipped separately and only count actual unfollows toward daily limit
      if (response.skipped) {
        if (!state.skipped) state.skipped = [];
        state.skipped.push(userId);
      } else {
        state.dailyUnfollowed = (state.dailyUnfollowed || 0) + 1;
      }
      
      // Different message for skipped (404) vs actually unfollowed
      const message = response.skipped 
        ? `⊘ Skipped ${state.currentIndex + 1}/${state.toUnfollow.length} (already gone)`
        : `✓ Unfollowed ${state.currentIndex + 1}/${state.toUnfollow.length} (${state.dailyUnfollowed} today)`;
      
      notifyPopup({
        type: 'progress',
        handle: 'ID:' + userId.slice(-6),
        added: state.added,
        failed: state.failed,
        skipped: state.skipped || [],
        message: message,
        success: true,
        total: state.toUnfollow.length,
      });
      state.currentIndex++;
      await chrome.storage.local.set({ fixfeed_process: state });
      const delay = response.skipped ? 500 : (5000 + Math.random() * 3000); // Faster for skipped
      setTimeout(processNextClean, delay);
    } else {
      throw new Error(response?.error || 'Unknown error');
    }
  } catch (e) {
    console.error('Failed to unfollow:', userId, e);
    
    // Check for rate limit (429 or 403)
    if (e.message && (e.message.includes('429') || e.message.includes('403') || e.message.includes('Rate limit'))) {
      console.log('Rate limit hit during clean, saving progress');
      state.running = false;
      
      // Calculate remaining
      const remainingIds = state.toUnfollow.slice(state.currentIndex);
      
      // Save progress for resume
      const progress = {
        mode: 'clean',
        listId: state.listId,
        toUnfollow: remainingIds,
        added: state.added,
        failed: state.failed,
        skipped: state.skipped || [],
        savedAt: new Date().toISOString()
      };
      await chrome.storage.local.set({ fixfeed_clean_progress: progress });
      
      notifyPopup({
        type: 'rateLimited',
        added: state.added,
        failed: state.failed,
        skipped: state.skipped || [],
        remainingHandles: remainingIds,
        message: `Rate limited. ${remainingIds.length} accounts remaining. Try again in 30-60 mins.`
      });
      return;
    }
    
    state.failed.push(userId);
    notifyPopup({
      type: 'progress',
      handle: 'ID:' + userId.slice(-6),
      added: state.added,
      failed: state.failed,
      skipped: state.skipped || [],
      message: `✗ Failed: ${e.message}`,
      success: false,
      total: state.toUnfollow.length,
    });
    state.currentIndex++;
    await chrome.storage.local.set({ fixfeed_process: state });
    const delay = 5000 + Math.random() * 3000;
    setTimeout(processNextClean, delay);
  }
}

// Notify popup of updates
function notifyPopup(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {
    // Popup might be closed, that's ok
  });
}

// Restore state on startup
chrome.runtime.onStartup.addListener(async () => {
  const stored = await chrome.storage.local.get(['fixfeed_process']);
  if (stored.fixfeed_process && stored.fixfeed_process.running) {
    state = stored.fixfeed_process;
    // Resume if was running
    if (!state.paused) {
      const tab = await findXTab();
      if (tab) {
        state.tabId = tab.id;
        if (state.mode === 'clean') {
          processNextClean();
        } else {
          processNext();
        }
      }
    }
  }
});
